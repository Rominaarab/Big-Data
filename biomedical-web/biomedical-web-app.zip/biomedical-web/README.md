# Biomedical Evidence Explorer — cloud web adapter

A small server-rendered web tool for collecting public biomedical records,
checking basic quality, and retrieving source-linked passages. The original
Python/Docker batch pipeline remains at https://github.com/Rominaarab/Big-Data/tree/main/biomedical-qa.

## Features

- Collect 1–25 records per source from PubMed, openFDA, and ClinicalTrials.gov.
- Inspect basic quality and partial source failures. Zero matching records is distinct from a failed request.
- Search one collection repeatedly using 160-word passages, 30-word overlap, TF-IDF and cosine similarity.
- Source filter and optional exact term/phrase required in the passage or title.
- Import the Python pipeline's documents.json or an exported collection.
- Download collection JSON, raw live response bodies, quality report, and search results.
- Bundled real snapshot of nine records, clearly distinguished from live acquisition.

This is a JavaScript Worker adapter rather than a running Python container. Unicode
tokenization and tie ordering can differ from scikit-learn, so scores are not
guaranteed identical. No LLM, supervised relation model, or medical confidence score
is claimed. No database is configured; a page refresh returns to the sample. Download
research you want to retain. The server receives documents for search and validation.

## Development and checks

No npm dependencies are required. On Node 22 or newer:

```
node scripts/test.mjs
node scripts/preview.mjs
node scripts/build.mjs
node scripts/validate-artifact.mjs
```

## Standalone container hosting

The same application can run on a Node/Docker cloud host with no build dependency
installation. Use `node scripts/server.mjs`, which listens on the host's `PORT`
environment variable (default 8080), or build the supplied Dockerfile. Health check:
`GET /api/health`. Optional server environment variables are `NCBI_EMAIL` and
`NCBI_API_KEY`; they are never returned to the browser.

The app contains no login system of its own. Keep the initial host private; a
public deployment needs explicit audience choice and shared rate limiting for
upstream APIs. Collection data is not persisted by the server.

The host uses a Worker ESM artifact. Build copies only the single Worker module
and hosting manifest. API secrets are optional server environment variables
NCBI_EMAIL and NCBI_API_KEY; never enter credentials in the public source.

This is a bounded prototype. A public, high-traffic deployment would need a shared
rate limiter/queue, durable research storage, explicit retention policies, and a
retrieval evaluation set. The initial hosted audience is owner-private.
