import http from 'node:http';
import worker from '../worker/index.js';
const server=http.createServer(async(req,res)=>{
  try{
    const buffers=[];for await(const chunk of req)buffers.push(chunk);
    const request=new Request('http://127.0.0.1:4317'+req.url,{method:req.method,headers:req.headers,...(!['GET','HEAD'].includes(req.method)?{body:Buffer.concat(buffers)}:{})});
    const response=await worker.fetch(request,{});
    res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
  }catch(e){res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}));}
});
server.listen(4317,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:4317'));
